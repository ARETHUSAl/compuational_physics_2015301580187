#include "zeus2d.def"
/*  Check if input is pending on stdin. If so, read it and return
    it to the caller.
  Output:
    msg		Buffer containing the text read from stdin.  */

#include <sys/time.h>

int checkin_(msg,wait,length)
int *msg,*wait,length;
{
  int mask,nfound,i;
  char *q;
  struct timeval timeout;

/* Something to read? */

  mask = 1;
  timeout.tv_sec = 0;
  timeout.tv_usec = 0;
  if(*wait)nfound = select(1,&mask,0,0,&timeout);
  else     nfound = 1;
  if(!nfound)return(0);

/* Do a read of the input, and pack it into an integer array. */

  nfound = read(0,msg,length) - 1;
  q = (char *)msg + nfound;
  for(i=nfound; i < length; i++) *q++ = ' ';
  return(nfound);
}
