      real  wa(in,jn) , wb(in,jn) , wc(in,jn) , wd(in,jn) 
     &, wi0 (in), wj0 (jn), wi10(in), wj10(jn), wij0 (ijn)
     &, wi1 (in), wj1 (jn), wi11(in), wj11(jn), wij1 (ijn)
     &, wi2 (in), wj2 (jn), wi12(in), wj12(jn), wij2 (ijn)
     &, wi3 (in), wj3 (jn), wi13(in), wj13(jn), wij3 (ijn)
     &, wi4 (in), wj4 (jn), wi14(in), wj14(jn), wij4 (ijn)
     &, wi5 (in), wj5 (jn), wi15(in), wj15(jn), wij5 (ijn)
     &, wi6 (in), wj6 (jn), wi16(in), wj16(jn), wij6 (ijn)
     &, wi7 (in), wj7 (jn), wi17(in), wj17(jn), wij7 (ijn)
     &, wi8 (in), wj8 (jn), wi18(in), wj18(jn), wij8 (ijn)
     &, wi9 (in), wj9 (jn), wi19(in), wj19(jn), wij9 (ijn)
     &, wi20(in), wj20(jn)
     &, wi21(in), wj21(jn)
     &, wi22(in), wj22(jn)
     &, wi23(in), wj23(jn)

      common /scratch/  wa,wb,wc,wd
     &                 ,wi0 , wi1 , wj0 , wj1 , wij0 , wij1
     &                 ,wi2 , wi3 , wj2 , wj3 , wij2 , wij3
     &                 ,wi4 , wi5 , wj4 , wj5 , wij4 , wij5
     &                 ,wi6 , wi7 , wj6 , wj7 , wij6 , wij7
     &                 ,wi8 , wi9 , wj8 , wj9 , wij8 , wij9
     &                 ,wi10, wi11, wj10, wj11
     &                 ,wi12, wi13, wj12, wj13
     &                 ,wi14, wi15, wj14, wj15
     &                 ,wi16, wi17, wj16, wj17
     &                 ,wi18, wi19, wj18, wj19
     &                 ,wi20, wi21, wj20, wj21
     &                 ,wi22, wi23, wj22, wj23
#ifdef GRAV
      real   wcg1(14*in*jn)
      common /iccgscr/ wcg1
#else
#ifdef RAD
      real   wcg1(14*in*jn)
      common /iccgscr/ wcg1
#endif
#endif
