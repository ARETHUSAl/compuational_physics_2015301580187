      real clight,me,mp,mh,boltz,h,guniv
      real msol,lsol
      real cmau,cmpc,cmkpc,cmkm,everg
c   physical constants (cgs)
      data clight  /2.99792e10     /,
     &     me      /9.14823e-29    /,
     &     mp      /1.67962e-24    /,
     &     mh      /1.66053e-24    /,
     &     boltz   /1.38062e-16    /,
     &     h       /6.62619e-27    /,
     &     guniv   /6.67323e-8     /
c   astronomical constants (cgs)
      data msol    /1.989e33       /,
     &     lsol    /3.826e33       /
c   conversion factors
      data cmau    /1.49597e13     /,
     &     cmpc    /3.0856e18      /,
     &     cmkpc   /3.0856e21      /,
     &     cmkm    /1.0e5          /,
     &     everg   /1.60184e-12    /

