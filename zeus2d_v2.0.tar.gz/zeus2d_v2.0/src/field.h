      real   d(in,jn),  e(in,jn),  p(in,jn), v1(in,jn), v2(in,jn)
#ifdef ROTATE
      real  v3(in,jn)
#endif
#ifdef GRAV
      real phi(in,jn)
#endif
#ifdef MHD
      real  b1(in,jn), b2(in,jn), b3(in,jn)
#endif
#ifdef RAD
      real  er(in,jn) 
#endif

      common /fieldr/  d ,  e,  p, v1, v2
#ifdef ROTATE
      common /fieldr/  v3
#endif
#ifdef GRAV
      common /fieldr/ phi
#endif
#ifdef MHD
      common /fieldr/  b1, b2, b3
#endif
#ifdef RAD
      common /fieldr/  er 
#endif
