      real    g,ptmass,epsgrv,phibverr,graverr
      integer izero,igriib,igroib,igrijb,igrojb,maxgrv,ks0grv,phibvnmx
      common /gravcomr/ g,ptmass,epsgrv,phibverr,graverr
      common /gravcomi/ izero,igriib,igroib,igrijb,igrojb,maxgrv,ks0grv
     &                  ,phibvnmx
