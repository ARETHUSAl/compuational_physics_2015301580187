      real    pi,tiny,huge
      integer in,jn,ijn
      parameter(pi   = 3.1415926535898)
      parameter(tiny = A_SMALL_NUMBER   )
      parameter(huge = A_BIG_NUMBER     )
      parameter(in  = NUM_OF_I_ZONES, jn = NUM_OF_J_ZONES)
      parameter(ijn = MAX_OF_IN_OR_JN)
