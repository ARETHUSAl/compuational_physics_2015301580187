/* ############################################################
      
     FILE:     cooling.h

     PURPOSE:  contains common definitions for the 
               whole CODE

   ############################################################ */

double GetMaxRate (double *, double *, double);
void Radiat (double *, double *);










